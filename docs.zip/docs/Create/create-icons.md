---
id: create-icons
title: Create icons
---

You can use any icon format (SVG or PNG is recommended to preserve transparency) and size you want and include it in your project. 

It's highly recommended having colored versions of your custom icons to better visualize them in the project editor.
For this tutorial, you can download the following icons:

<div markdown="1" style="text-align: center; margin-top: 20px">
<a class="button"
href="../assets/en/custom-icons/Custom-Icons.zip">CUSTOM ICONS</a>
</div>

