---
id: project-editor-main-menu-section
title: Main Menu
---

* In the **Available Table** list, you'll find all of the tables you published earlier in the Structure section.
The **Selected Tables** list includes all of the tables that will be accessible from the menu of your app.

* By default, all selected tables from the Structure section will be added to your app’s menu. You can then drag and drop them to add, delete, and reorder them.

![Main menu section](docs/assets/Main-menu-section-4D-for-iOS.png)
